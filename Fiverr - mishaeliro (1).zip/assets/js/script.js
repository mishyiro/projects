const mainHeader = document.getElementById('mainHeader');
const animatedElemets = document.querySelectorAll('.animated-element');

const toggleClass = (className, elementId) => {
	try{
		document.getElementById(elementId).classList.toggle(className);
	}catch(e){
		console.log(`toggleClass function error: Either params aren't provided or element with ${elementId} doesn't exist.`);
	}
}

window.addEventListener('scroll', () => {
	mainHeader.classList.remove('nav-active');
});

const observer = new IntersectionObserver(entries => {
	entries.forEach(entry => {
		entry.target.classList.toggle('in-view', entry.isIntersecting);
		if(entry.isIntersecting) observer.unobserve(entry.target);
	});
}, { threshold: 0.25 });

animatedElemets.forEach(element => {
	observer.observe(element);
});