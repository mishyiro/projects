const jumpToSlide = (slideId, e) => {
    const active = document.querySelectorAll('.slider-jumper.active, .slider-slide.active');
    const newSlide = document.getElementById(slideId);

    if(newSlide){
        active.length > 0 && removeClass(active, 'active');
        e.classList.add('active');
        newSlide.classList.add('active');
        newSlide.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
        
    }
}

const removeClass = (elements, className) => {
    elements.forEach(element => {
        element.classList.remove(className);
    });
}

window.onresize = (e) => {
    const slidesContainer = document.querySelector('.slider-slides-container');
    const activeSlider = document.querySelector('.slider-slide.active');

    slidesContainer.scroll({
        left: activeSlider.offsetLeft,
        behavior: 'smooth',
        block: 'start'
    });
}

const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
}