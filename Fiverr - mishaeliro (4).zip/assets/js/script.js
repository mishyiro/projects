const mainHeaderNavToggleButton = document.getElementById('mainHeaderNavToggleButton');
const navLinks = document.querySelectorAll('.main-header-nav > a');
const footerYear = document.getElementById('footerYear');

mainHeaderNavToggleButton.addEventListener('click', () => {
    document.body.classList.toggle('main-nav-active');
});

document.addEventListener('scroll', () => {
    document.body.classList.remove('main-nav-active');
});

footerYear.textContent = new Date().getFullYear();