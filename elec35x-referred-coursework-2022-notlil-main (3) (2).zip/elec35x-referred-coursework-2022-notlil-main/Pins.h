// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#ifndef Board_Pins 
#define Board_Pins
#include "mbed.h"
#include "uop_msb.h"

typedef struct {
    PinName MOSI;
    PinName MISO;
    PinName SCLK;
    PinName CS;
    PinName OE;
}SPI_pins_t;

//Initialise the Environmental Sensors in SPI
const SPI_pins_t BMP_280_Pins {
    PB_5,
    PB_4,
    PB_3,
    PB_2 
};

//Initialise the SD in SPI
const SPI_pins_t SD_Pins {
    PB_5,
    PB_4,
    PB_3,
    PF_3
};

//COME BACK & INTEGREATE THRESHOLDS 
typedef struct{ // create a structure that stores all the sensor data. 
    bool present;
    double mbar; // pressure
    double temp; //  temperature 
    double lumens; // light 
    char date[11];
    char time[9];

}reading_t;

typedef struct {
    PinName IOE;

    PinName LED1;
    PinName LED2;
    PinName LED3;
    PinName LED4;
    PinName LED5;
    PinName LED6;
    PinName LED7;
    PinName LED8;
//Pins for Led bar
}STRIP_Pins;
const STRIP_Pins ALL_Pins {
    PE_0,
    PE_2,
    PE_3,
    PE_4,
    PE_5,
    PE_6,
    PE_7,
    PE_8,
    PE_9
};



const PinName BlueButton = PC_13;
const PinName RedLED = PC_3;


#endif