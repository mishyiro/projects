// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#ifndef Env_Sensor
#define Env_Sensor
#include "mbed.h"
#include "uop_msb.h"

using namespace uop_msb;

const uint32_t buffer_size = 16; // size of sd buffer
const uint32_t buffer_nearFull = (buffer_size - 1); // hold sd buffer till near full

class data{
    private:
    //*************** Sensor data *****************************
        double l{};
        double t{};
        double p{};

        double light_lower{0.9};
        double light_upper{0.1};
        double temp_lower{15};
        double temp_upper{28};
        double pressure_lower{1000};
        double pressure_upper{1100};

        friend int Sample_Thread();

    //****************** Mutex to lock thread *************************
        Mutex datalock;

        EnvSensor Sensor; //Pins for the sensor

    public:
        data(); //initialize empty data types for environmental sensor data

        data(double light, double temperature, double pressure); //initialize data types for environmental sensor data

        //************Getter methods to retrieve threshold values*******************
        double getlight_min() {return this->light_lower;}
        double getlight_max() {return this->light_upper;}
        double gettemp_min() {return this->temp_lower;}
        double gettemp_max() {return this->temp_upper;}
        double getpressure_min() {return this->pressure_lower;}
        double getpressure_max() {return this->pressure_upper;}

        //*************Setter methods to set threshold values***********************
        void setlight_min(double value) {this->light_lower = value;}
        void setlight_max(double value) {this->light_upper = value;}
        void settemp_min(double value) {this->temp_lower = value;}
        void settemp_max(double value) {this->temp_upper = value;}
        void setpressure_min(double value) {this->pressure_lower = value;}
        void setpressure_max(double value) {this->pressure_upper = value;}

        double getlight(); //read light from "uop_msb.h" via inheritance

        double gettemp(); //read temp from "uop_msb.h" via inheritance

        double getpressure(); //read pressure from "uop_msb.h" via inheritance

        void updateData(double light, double temperature, double pressure); //updates data from LDR sensor

       // ********************** lock and unlock data ************************************
        void lock();

        void unlock();
        //******************************************
        double sensorPressure(); //input sensor pressure

        double sensorTemperature(); //input sensor temperature

};

#endif