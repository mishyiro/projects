// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#include "mbed.h"
#include "SDBlockDevice.h"
#include"FATFileSystem.h"
#include "FIFObuff.h"
#include "Pins.h"

#if(MBED_CONF_RTOS_PRESENT ==1)
#if(MBED_CONF_SD_FSAT_SDCARD_INSTALLED ==1)
#define USE_SD_CARD

#endif
#endif

class SDcard{
private:

  SDBlockDevice sd; 
  FATFileSystem fs;
  FILE *fp;
  
  double _lightSend;
  double _tempSend;
  double _pressureSend;
  
public:
   
  SDcard(SPI_pins_t pins);
   
  int Txtcreate(); //create new txt file

  int SDread(); //read text in SDcard
  /********************************************************************
-fuction  bufferSD
-brief    using buffer class to collect envsesnsor data
*/       
 
  int SDwrite(); //write data from buffer to text file

  void writeBufferData(double light, double temperature, double pressure); 
};
