// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#include "FIFObuff.h"
#include <cstdint>
using namespace uop_msb;

//functions explained in FIFObuff.h

void buffer::updateBuffer(uint32_t light, uint32_t temp, uint32_t pressure){

            this->_sentLdata = this->lightQ.try_put((uint32_t*)light);
            this->_sentTdata = this->tempQ.try_put((uint32_t*)temp);
            this->_sentPdata = this->pressureQ.try_put((uint32_t*)pressure);
}

int buffer::readCounter(){
    return this-> counter;        
}

void buffer::countInc(){
    this-> counter = this-> counter+1;
}

void buffer::countDec(){
    this-> counter = this-> counter-1;
}

double buffer::readLight(){
    uint32_t* qLight;
    this-> lightQ.try_get_for(10s, &qLight); //tries, to get value from buffer(queue) and puts it in address qLight
    double lightSend = (double)(uint32_t)qLight/100; //tells compiler that we want the value not the referance

    return lightSend;
}

double buffer::readTemp(){

    uint32_t* qTemp;
    this->tempQ.try_get_for(10s, &qTemp); //tries, to get value from buffer(queue) and puts it in address qTemp
    double tempSend = (double)(uint32_t)qTemp/100; //tells compiler that we want the value not the referance

    return tempSend;
}

double buffer::readPress(){
    uint32_t* qPress;
    this-> pressureQ.try_get_for(10s, &qPress);//tries, to get value from buffer(queue) and puts it in address qLight
    double pressureSend = (double)(uint32_t)qPress/100; //tells compiler that we want the value not the referance

    return pressureSend;
}

bool buffer::lightSent(){
    return this->_sentLdata;
}

bool buffer::tempSent(){
    return this->_sentTdata;
}

bool buffer::pressureSent(){
    return this->_sentPdata;
}

int buffer::showAll()
{
    return 0;
}



