// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil

#ifndef _STRIP_H__
#define _STRIP_H__

#include "mbed.h"
#include "uop_msb.h"
#include <cstdint>
#include "Pins.h"
#include "EnvSensor.h"
#include "FIFObuff.h"
class Strip {
            
    private:
        //LatchedLED sevenSeg;
        DigitalOut PE_0;
        DigitalOut PE_2;
        DigitalOut PE_3;
        DigitalOut PE_4;
        DigitalOut PE_5;
        DigitalOut PE_6;
        DigitalOut PE_7;
        DigitalOut PE_8;
        DigitalOut PE_9;

    public:
        Strip(STRIP_Pins pins); //sevenSeg(LatchedLED::LEDMODE::SEVEN_SEG)
        // {
        //     //CONSTRUCTOR
        // }

         void RunDisplay(); //display data in bars   

};



#endif
