// *************
// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil

#include "mbed.h"
#include "uop_msb.h"
#include "EnvSensor.h"
#include "FIFObuff.h"
#include "SDcard.h"
#include "Strip.h"
#include <iostream>

using namespace uop_msb;

data envsensordata; // instance of the sensor data class

AnalogIn ldr(AN_LDR_PIN); //Instance of Analogin class, LDR

Buzzer buzz; //Instance of buzzer class

Strip Bar(ALL_Pins);//Instance of LED strip class

Thread t1(osPriorityAboveNormal); //sample thread with highest priority
Thread t2;
Thread t3;
Thread t4;

int Sample_Thread()
{
    while(1)
    {
        uint32_t light = ldr*100;
        uint32_t temperature = envsensordata.sensorTemperature()*100;
        uint32_t pressure = envsensordata.sensorPressure()*100;

        if (((double)light/100) < envsensordata.light_upper || ((double)light/100) > envsensordata.light_lower) 
        {
            if(((double)light/100) < envsensordata.light_upper)
            {
                buzz.playTone("A", Buzzer::HIGHER_OCTAVE);
            }
            else
            {
                buzz.playTone("A", Buzzer::LOWER_OCTAVE);
            }
            wait_us(100000);
            buzz.rest();
        }
        
        if (((double)temperature/100) > envsensordata.temp_upper || ((double)temperature/100) < envsensordata.temp_lower) 
        {
            if(((double)temperature/100) > envsensordata.temp_upper)
            {
                buzz.playTone("B", Buzzer::HIGHER_OCTAVE);
            }
            else 
            {
                buzz.playTone("B", Buzzer::LOWER_OCTAVE);
            }
            wait_us(300000);
            buzz.rest();
        }

        if (((double)pressure/100) > envsensordata.pressure_upper || ((double)pressure/100) < envsensordata.pressure_lower) 
        {
            if(((double)pressure/100) > envsensordata.pressure_upper)
            {
                buzz.playTone("C", Buzzer::HIGHER_OCTAVE);
            }
            else 
            {
                buzz.playTone("C", Buzzer::LOWER_OCTAVE);
            }
            wait_us(500000);
            buzz.rest();
        }

        envsensordata.lock();
        envsensordata.updateData(((double)light/100), ((double)temperature/100), ((double)pressure/100));
        std::cout << ((double)light/100) << " " << ((double)temperature/100) << " " << ((double)pressure/100) << std::endl;
        envsensordata.unlock();

        ThisThread::sleep_for(1s);
    }
    return 0; 
}

buffer FIFO;// Instance of buffer class
SDcard SD(SD_Pins);//Instance of SDcard class
//sd card thread
int ReadWrite_Thread()
{
    while (true)
    {
        double Bufflight = FIFO.readLight();
        double Bufftemp = FIFO.readTemp();
        double Buffpress = FIFO.readPress();
        
        SD.writeBufferData(Bufflight, Bufftemp, Buffpress);
        SD.Txtcreate();
        //ThisThread::sleep_for(60s); ---- one minute (for test)
        ThisThread::sleep_for(3600s);
    }
    return 0;
}
//buffer thread
int FIFO_Thread(){
    while(true){
        envsensordata.lock();
        uint32_t light = envsensordata.getlight()*100;
        uint32_t temp = envsensordata.gettemp()*100;
        uint32_t pressure = envsensordata.getpressure()*100;

        envsensordata.unlock();
        FIFO.updateBuffer(light, temp, pressure);

        ThisThread::sleep_for(10s);

        if(!FIFO.lightSent()||!FIFO.tempSent()||!FIFO.pressureSent()){
            printf("\nError: Sensor data failed to send to queue!");
        }
    }
    return 0;
}
//display led bar strip
void displayStrip_Thread(){
    while(1){
        ThisThread::sleep_for(3ms);
        Bar.RunDisplay();
        envsensordata.updateData(envsensordata.getlight(), envsensordata.gettemp(), envsensordata.getpressure());
    }
}

int main() {

    t1.start(Sample_Thread);//envsensor thread
    t2.start(FIFO_Thread);//buffer thread
    t3.start(ReadWrite_Thread);//sd card thread
    t4.start(displayStrip_Thread);//display led bar strip

    return 0;
}
