// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#include <Strip.h>

data envdata;

Strip::Strip(STRIP_Pins Pins):
                            PE_0(Pins.IOE), //IOE pin blocks
                            PE_2(Pins.LED1),
                            PE_3(Pins.LED2),
                            PE_4(Pins.LED3),
                            PE_5(Pins.LED4),
                            PE_6(Pins.LED5),
                            PE_7(Pins.LED6),
                            PE_8(Pins.LED7),
                            PE_9(Pins.LED8)
    {
    }

void Strip::RunDisplay()
{
    PE_0 = 0;

    if (envdata.getlight() <= 1) {
        if (envdata.getlight() < 0.1125) 
        {
            PE_2 = 1;
            PE_3 = PE_4 = PE_5 = PE_6 = PE_7 = PE_8 = PE_9 = 0;
            // wait_us(100000);
            //envdata.updateData(light, temp, press);
        }
        else if (envdata.getlight() < 0.225) 
        {
            PE_2 = PE_3 = 1;
            PE_4 = PE_5 = PE_6 = PE_7 = PE_8 = PE_9 = 0;
        }
        else if (envdata.getlight() < 0.3375) 
        {
            PE_2 = PE_3 = PE_4 = 1;
            PE_5 = PE_6 = PE_7 = PE_8 = PE_9 = 0;
        }
        else if (envdata.getlight() < 0.45) 
        {
            PE_2 = PE_3 = PE_4 = PE_5 = 1;
            PE_6 = PE_7 = PE_8 = PE_9 = 0;
        }
        else if (envdata.getlight() < 0.5625) 
        {
            PE_2 = PE_3 = PE_4 = PE_5 = PE_6 = 1;
            PE_7 = PE_8 = PE_9 = 0;
        }
        else if (envdata.getlight() < 0.675)
        {
            PE_2 = PE_3 = PE_4 = PE_5 = PE_6 = PE_7 = 1;
            PE_8 = PE_9 = 0;
        }
        else if (envdata.getlight() < 0.7875)
        {
            PE_2 = PE_3 = PE_4 = PE_5 = PE_6 = PE_7 = PE_8 = 1;
            PE_9 = 0;
        }
        else if (envdata.getlight() < 0.9)
        {
            PE_2 = PE_3 = PE_4 = PE_5 = PE_6 = PE_7 = PE_8 = PE_9 = 1;
        }
    }
// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     if (envdata.gettemp() < 16.625)
//     {
//         sevenSeg = 16;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 18.25)
//     {
//         sevenSeg = 32;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 19.875)
//     {
//         sevenSeg = 48;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 21.5)
//     {
//         sevenSeg = 64;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 23.125)
//     {
//         sevenSeg = 80;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 24.75) 
//     {
//         sevenSeg = 96;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 26.375)
//     {
//         sevenSeg = 112;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
//     else if (envdata.gettemp() < 28)
//     {
//         sevenSeg = 128;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::GREEN);
//     }
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     if (envdata.getpressure() < 1012.5)
//     {
//         sevenSeg = 16;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1025)
//     {
//         sevenSeg = 32;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1037.5)
//     {
//         sevenSeg = 48;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1050)
//     {
//         sevenSeg = 64;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1062.5)
//     {
//         sevenSeg = 80;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1075) 
//     {
//         sevenSeg = 96;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1087.5)
//     {
//         sevenSeg = 112;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }
//     else if (envdata.getpressure() < 1100)
//     {
//         sevenSeg = 128;
//         wait_us(100000);
//         sevenSeg.setGroup(LatchedLED::LEDGROUP::BLUE);
//     }

    wait_us(250000);
    //PE_0 = 1;
}