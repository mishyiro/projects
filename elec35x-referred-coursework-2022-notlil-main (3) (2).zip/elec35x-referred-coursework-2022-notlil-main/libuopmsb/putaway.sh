mv main.cpp main.cpp.txt
mv mbed-os.lib mbed-os.lib.txt
mv mbed_app.json mbed_app.json.txt
