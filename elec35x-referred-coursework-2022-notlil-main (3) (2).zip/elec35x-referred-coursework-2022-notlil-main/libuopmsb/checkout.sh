mv main.cpp.txt main.cpp
mv mbed-os.lib.txt mbed-os.lib
mv mbed_app.json.txt mbed_app.json
