// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#ifndef buff
#define buff
#include "mbed.h"
#include "uop_msb.h"
#include "EnvSensor.h"
#include <cstdint>


using namespace uop_msb;
 
class buffer {
    private:
        Queue<uint32_t, 10> lightQ; 
        Queue<uint32_t, 10> tempQ;
        Queue<uint32_t, 10> pressureQ;

        bool _sentLdata;
        bool _sentTdata;
        bool _sentPdata;
        int counter = 10;
    
    public:

        buffer(){} //instance of buffer class

        void updateBuffer(uint32_t light, uint32_t temp, uint32_t pressure); //update bool vslues after inserting sensor data into buffer 

        int readCounter(); //access counter value and return it

        void countInc(), countDec(); //increment counter by 1 && decrement counter by 1

        double readLight(), readTemp(), readPress();// read light, temperature and pressure values

        int showAll();

        bool lightSent(), tempSent(), pressureSent(); // check if data has been sent

};

#endif