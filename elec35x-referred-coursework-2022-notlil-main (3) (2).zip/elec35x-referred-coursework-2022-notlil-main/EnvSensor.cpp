// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#include "EnvSensor.h"

//**********************initialize data types***************************
data::data(double light, double temperature, double pressure){
    this->l=light;
    this->t=temperature;
    this->p=pressure;
}

//****************************8 initialize empty data types*********
data::data(){
    this-> l = 0;
    this-> t = 0;
    this-> p =0;
}

double data::getlight(){ //read data from uopmsb and return value of light as double
    return this-> l;
}

double data::gettemp(){ //read data from uopmsb and return value of temperature as double
    return this-> t;
}

double data::getpressure(){ //read data from uopmsb and return value of pressure as double
    return this-> p;
}

double data::sensorPressure(){ //input sensor pressure
    return this->Sensor.getPressure();
}

double data::sensorTemperature(){ //input sensor temperature
    return this->Sensor.getTemperature();
}

void data::updateData(double light, double temp, double pressure){ //update LDR sensor values
    this-> l = light;
    this-> t = temp;
    this-> p = pressure; 
}
//****************lock and unlock data*********************************
void data::lock(){
    this->datalock.lock();
}

void data::unlock(){
    this->datalock.unlock();
}