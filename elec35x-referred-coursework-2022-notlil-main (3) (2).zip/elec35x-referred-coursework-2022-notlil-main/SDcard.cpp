// Name: Mishael Chukwuemeka-Iro
// student number: 10669649
// *************

// GitHub name: notlil
#include "SDcard.h"
//Constructor
SDcard ::SDcard(SPI_pins_t pins): 
                                 sd(pins.MOSI, pins.MISO, pins.SCLK, pins.CS),
                                 fs("sd", &sd){

         }
/********************************************************************
-fuction  writeSD
-brief    using class to make a text file
*/       
       
int SDcard::Txtcreate() //Calling on the class 
{
    printf("Create Txt and write to a file\n");
 int err;
    // call the SDBlockDevice instance initialisation method.

    err=sd.init();
    if ( 0 != err) {
        printf("Txt creation failed %d\n",err);
        return -1;
    }
    
    FATFileSystem fs("sd", &sd);
    FILE *fp = fopen("/sd/EVdata.txt","w"); //opens a txt file on the SD card
    if(fp == NULL) {                                    
        error("Could not open file for write\n"); //returns error if there is no file
        sd.deinit();
        return -1;
    } else {
        fprintf(fp, "SD Initialised\n");
        fprintf(fp, "{ \"LightLevel\" : %5.2f, \"Temperature\" : %5.2f, \"Pressure\" : %5.2f}\n", this->_lightSend, this->_tempSend, this->_pressureSend);
        //Tidy up here
        fclose(fp);
        printf("SD Write done...\n");
        sd.deinit();
        return 0;
    }
    
}
/********************************************************************
-fuction  readSD
-brief    using class to read data in text file
*/       
int SDcard::SDread() //Calling on the class
{
    printf("Initialise and read from a file\n");

    // call the SDBlockDevice instance initialisation method.
    if ( 0 != sd.init()) {
        printf("Init failed \n");
        return -1;
    }
    
    FATFileSystem fs("sd", &sd);
    FILE *fp = fopen("/sd/EVdata.txt","r");
    if(fp == NULL) {
        error("File not found/could not write to file\n");
        sd.deinit();
        return -1;
    } else {
        //Put text in the file...
        char buffr[64]; buffr[63] = 0;
        while (!feof(fp)) {
            fgets(buffr, 63, fp);
            printf("%s\n", buffr);
        }
        //Tidy up here
        fclose(fp);
        printf("Writing to SD complete...\n");
        sd.deinit();
        return 0;
    }
}

void SDcard::writeBufferData(double light, double temperature, double pressure){
    this->_lightSend = light;
    this->_tempSend = temperature;
    this->_pressureSend = pressure;
}

